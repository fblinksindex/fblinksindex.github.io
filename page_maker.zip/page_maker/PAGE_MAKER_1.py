import uiautomator2 as u2
import wget
import requests
import random
import time
d = u2.connect()

with open("names.txt", "r") as name:
    names = [g.strip() for g in name]


def remove_link_from_file(filename, link):
    with open(filename, 'r') as file:
        lines = file.readlines()
    lines = [line for line in lines if link not in line]
    with open(filename, 'w') as file:
        file.writelines(lines)
website ="https://techtalkhub.click/"
with open("page_maker.txt","r") as v:
    ids = [x.strip() for x in v]

v = random.choice(ids)
name = random.choice(names)
# print(name)
# print(v)
# data = requests.get(f"https://tube2.me/api/video/{v}").json()
# if data['video']:
#
#     if data['video']['items']:
#
#         c = v
#         if data['video']['items']:
#
#             if 'maxres' in data['video']['items'][0]['snippet']['thumbnails']:
#                 url = data['video']['items'][0]['snippet']['thumbnails']['maxres']['url']
#                 wget.download(url, f"{c}.jpg")
#                 time.sleep(5)
#             else:
#                 url = data['video']['items'][0]['snippet']['thumbnails']['medium']['url']
#                 wget.download(url, f"{c}.jpg")
#                 time.sleep(5)
#
#             d.push(f"{c}.jpg", "/sdcard/")
#             time.sleep(5)
#             b = f'am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///storage/emulated/0/{c}.jpg'
#             output, exit_code = d.shell(b, timeout=60)
#             b = f'am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///storage/emulated/0/{c}.jpg'
#             output2, exit_code2 = d.shell(b, timeout=60)
#
#             time.sleep(5)
#             output1, exit_code1 = d.shell(f'ls /sdcard/{c}.jpg', timeout=60)
#             print(exit_code1)
#             if exit_code1 == 0:
imdata = "menu.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
time.sleep(1)

imdata = "pages.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
time.sleep(1)
imdata = "create.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
time.sleep(1)

imdata = "get_start.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
time.sleep(1)

d(text="Page name").set_text(name)
time.sleep(1)

imdata = "next.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
time.sleep(2)
imdata = "add_categore.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
time.sleep(5)
d.click(0.422, 0.273)
imdata = "next1.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
time.sleep(5)
d(text="Enter website").set_text(website)
imdata = "next1.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
imdata = "done.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
d.image.match(imdata)
d.image.click(imdata, timeout=20.0)
time.sleep(10)

                # d().swipe("down", steps=20)
                # time.sleep(5)
                # d().swipe("down", steps=20)
                # time.sleep(5)
                #
                # imdata = "camlogo.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
                # d.image.match(imdata)
                # d.image.click(imdata, timeout=20.0)
                # imdata = "upload.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
                # d.image.match(imdata)
                # d.image.click(imdata, timeout=20.0)
                # d.press("back")  # press the back key, with key name
                # time.sleep(15)
                # imdata = "camlogo.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
                # d.image.match(imdata)
                # d.image.click(imdata, timeout=20.0)
                # imdata = "upload.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
                # d.image.match(imdata)
                # d.image.click(imdata, timeout=20.0)
                # d.click(0.492, 0.541)
                # imdata = "update.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
                # d.image.match(imdata)
                # d.image.click(imdata, timeout=20.0)
                # imdata = "change_profile.png"  # 也可以是URL, PIL.Image或OpenCV打开的图像
                # d.image.match(imdata)
                # d.image.click(imdata, timeout=20.0)
                # d.xpath(
                #     '//*[@resource-id="com.facebook.lite:id/main_layout"]/android.widget.FrameLayout[1]/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup[4]/android.view.View[2]').click()
