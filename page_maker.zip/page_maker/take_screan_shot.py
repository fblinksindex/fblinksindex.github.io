import uiautomator2 as u2
import time
d = u2.connect()
im =d.xpath('//*[@resource-id="com.facebook.lite:id/main_layout"]/android.widget.FrameLayout[1]/android.view.ViewGroup[4]/android.view.ViewGroup[2]').screenshot()
im.save("add_categore.png")
# name = "美好时刻"
# website = "cat.com"
# imdata = "next.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# x = d.image.match(imdata)
# print(x)
# d.image.click(imdata, timeout=20.0)
# imdata = "pages.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# imdata = "create.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# imdata = "get_start.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# d(text="Page name").set_text(name)
# imdata = "next.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# time.sleep(2)
# imdata = "add_categore.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# time.sleep(5)
# d.click(0.422, 0.273)
# imdata = "next1.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# time.sleep(5)
# d(text="Enter website").set_text(website)
# imdata = "next1.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# imdata = "done.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# time.sleep(10)
#
# d().swipe("down", steps=20)
# time.sleep(5)
# d().swipe("down", steps=20)
# time.sleep(5)
#
#
# imdata = "camlogo.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# imdata = "upload.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# d.press("back") # press the back key, with key name
# time.sleep(1)
# imdata = "camlogo.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# imdata = "upload.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# d.click(0.492, 0.541)
# imdata = "update.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# imdata = "change_profile.png" # 也可以是URL, PIL.Image或OpenCV打开的图像
# d.image.match(imdata)
# d.image.click(imdata, timeout=20.0)
# d.xpath('//*[@resource-id="com.facebook.lite:id/main_layout"]/android.widget.FrameLayout[1]/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup[4]/android.view.View[2]').click()